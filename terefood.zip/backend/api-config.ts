export const apiConfig = {
  secret: 'terefood-password'
}
