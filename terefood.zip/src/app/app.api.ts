/* A url estava com um p no final - http://localhost:3000p */
export const MEAT_API = 'https://localhost:3001'
